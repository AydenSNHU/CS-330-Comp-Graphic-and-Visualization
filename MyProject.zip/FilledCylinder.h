#pragma once
#include "common/staticMesh3D.h"

namespace static_meshes_3D {

	/**
	* FilledCylinder static mesh with given radius, number of slices and height.
	*/
	class FilledCylinder : public StaticMesh3D
	{
	public:
		FilledCylinder(float radius, int numSlices, float height,
			bool withPositions = true, bool withTextureCoordinates = true, bool withNormals = true);

		void render() const override;
		void renderPoints() const override;

		/**
		 * Gets FilledCylinder radius.
		 */
		float getRadius() const;

		/**
		 * Gets number of FilledCylinder slices.
		 */
		int getSlices() const;

		/**
		 * Gets FilledCylinder height.
		 */
		float getHeight() const;

	private:
		float _radius; // FilledCylinder radius (distance from the center of FilledCylinder to surface)
		int _numSlices; // Number of FilledCylinder slices
		float _height; // Height of the FilledCylinder

		int _numVerticesSide; // How many vertices to render side of the FilledCylinder
		int _numVerticesTopBottom; // How many vertices to render top / bottom of the FilledCylinder
		int _numVerticesTotal; // Just a sum of both numbers above

		void initializeData() override;
	};

} // namespace static_meshes_3D
