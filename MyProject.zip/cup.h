#pragma once
#include "common/staticMesh3D.h"

namespace static_meshes_3D {

	/**
	* Cup static mesh with given radius, number of slices and height.
	*/
	class Cup : public StaticMesh3D
	{
	public:
		Cup(float radius, int numSlices, float height,
			bool withPositions = true, bool withTextureCoordinates = true, bool withNormals = true);

		void render() const override;
		void renderPoints() const override;

		/**
		 * Gets cup radius.
		 */
		float getRadius() const;

		/**
		 * Gets number of cup slices.
		 */
		int getSlices() const;

		/**
		 * Gets cup height.
		 */
		float getHeight() const;

	private:
		float _radius; // Cup radius (distance from the center of cup to surface)
		int _numSlices; // Number of cup slices
		float _height; // Height of the cup

		int _numVerticesSide; // How many vertices to render side of the cup
		int _numVerticesTopBottom; // How many vertices to render top / bottom of the cup
		int _numVerticesTotal; // Just a sum of both numbers above

		void initializeData() override;
	};

} // namespace static_meshes_3D