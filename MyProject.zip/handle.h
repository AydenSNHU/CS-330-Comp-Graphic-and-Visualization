#pragma once
#include "common/staticMesh3D.h"

namespace static_meshes_3D {

	/**
	* Handle static mesh with given radius, number of slices and height.
	*/
	class Handle : public StaticMesh3D
	{
	public:
		Handle(float radius, int numSlices, float height,
			bool withPositions = true, bool withTextureCoordinates = true, bool withNormals = true);

		void render() const override;
		void renderPoints() const override;

		/**
		 * Gets handle radius.
		 */
		float getRadius() const;

		/**
		 * Gets number of handle slices.
		 */
		int getSlices() const;

		/**
		 * Gets handle height.
		 */
		float getHeight() const;

	private:
		float _radius; // Handle radius (distance from the center of handle to surface)
		int _numSlices; // Number of handle slices
		float _height; // Height of the handle

		int _numVerticesSide; // How many vertices to render side of the handle
		int _numVerticesTopBottom; // How many vertices to render top / bottom of the handle
		int _numVerticesTotal; // Just a sum of both numbers above

		void initializeData() override;
	};

} // namespace static_meshes_3D